defmodule Background.Scheduler do
  use Quantum, otp_app: :background
end