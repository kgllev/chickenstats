export default function () {
  return {
    chicken_derbies: [],
    loading: false
  }
}
